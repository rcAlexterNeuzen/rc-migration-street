# CHANGELOG VERSION 1.3

## New functionality
### Install-RCMigrationStreet.ps1
- added function for console logging
- added version.json
- added backup functionality

### Install-App-Registration.ps1
- added creation of sharepoint-information.psd1 and teams-and-spo-information.psd1 to install-app-registration.ps1


## Changes
- Code cleanup
- Moved PSD functions to rc-migration-module.psm1

