# Import-Data for the powershell modules and your needs

- App-Registration.psd1 : https://dev.azure.com/AlexterNeuzen/_git/rc-migration-street?path=/import-data/app-registration.md
- Graph-Api-Urls.psd1 : 
- required-modules.psd1  : 